/*
Package testutil contains operations useful for testing. In particular,
it provides fake connections useful for testing client/server interactions.
*/
package testutil
