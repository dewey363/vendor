package frame

import (
	"errors"
)

var (
	ErrInvalidHeartBeat = errors.New("invalid heart-beat")
)
